using PersonalChannelWebAPI.Controllers;
using PersonalChannelWebAPI.Models;
using System;
using System.Web.Http.Results;
using Xunit;

namespace TestWebAPI
{
    public class UnitTest1
    {
        Task GetDemoProduct()
        {
            return new Task() { Id = 3, Name = "Demo name", IsComplete = false };
        }

        [Fact]
        public void Test1()
        {
            var controller = new TasksController(new WebAPIPersonalChannelContext());
            var item = GetDemoProduct();

            //var result =
              /*  controller.AddTask(item) as CreatedAtRouteNegotiatedContentResult<Task>;

            Assert.NotNull(result);
            Assert.Equal(result.RouteName, "DefaultApi");
            Assert.Equal(result.RouteValues["id"], result.Content.Id);
            Assert.Equal(result.Content.Name, item.Name);*/
        }
    }
}
