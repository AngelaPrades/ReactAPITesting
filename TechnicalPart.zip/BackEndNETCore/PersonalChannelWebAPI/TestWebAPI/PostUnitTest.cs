﻿using Microsoft.EntityFrameworkCore;
using Moq;
using PersonalChannelWebAPI.Models;
using PersonalChannelWebAPI.Repositories;
using PersonalChannelWebAPI.Controllers;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Xunit;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Web.Http;
using Microsoft.AspNetCore.Http;
using FluentAssertions;

namespace TestWebAPI
{
    public class PostUnitTest
    {
        private TaskRepository repository;
        public static DbContextOptions<WebAPIPersonalChannelContext> dbContextOptions { get; }
        public static string connectionString = "Server=DESKTOP-R5QTV9O\\SQLEXPRESS;Database=WebAPIPersonalChannel;Integrated Security=true";

        static PostUnitTest()
        {
            dbContextOptions = new DbContextOptionsBuilder<WebAPIPersonalChannelContext>()
                .UseSqlServer(connectionString)
                .Options;
        }

        private List<PersonalChannelWebAPI.Models.Task> GetTestTasks()
        {
            return new List<PersonalChannelWebAPI.Models.Task>()
            {
                new PersonalChannelWebAPI.Models.Task(){Id=1, Name="Task 1 Test", IsComplete=false },
                new PersonalChannelWebAPI.Models.Task(){Id=2, Name="Task 2 Test", IsComplete=false }
            };

        }

        [Fact]
        public async void GetReturnsNotFound()
        {
            // Arrange
            var mockRepository = new Mock<ITaskRepository>();
            var controller = new TasksController(mockRepository.Object);

            // Act
            Task<IActionResult> actionResult = controller.GetTaskById(10);

            // Assert
            //var okResult = actionResult as NotFoundObjectResult;

            // assert
            Assert.NotNull(actionResult);
            //actionResult.Should().BeOfType<NotFoundObjectResult>();
            Assert.IsAssignableFrom<NotFoundResult>(actionResult.Result);
            //Assert.Equal(StatusCodes.Status404NotFound.ToString(), actionResult.Status.ToString());
        }

        [Fact]
        public async void GetReturnsFound()
        {
            var mockRepository = new Mock<ITaskRepository>();
            var controller = new TasksController(mockRepository.Object);
            mockRepository.Setup(repo => repo.AddTaskAsync(this.GetTestTasks().First()));
            var result = controller.AddTask(this.GetTestTasks().First()).Result;
            Task<IActionResult> actionResult = controller.GetTaskById(1);

            Assert.NotNull(actionResult);
            Assert.IsAssignableFrom<OkResult>(actionResult.Result);
        }

        [Fact]
        public void Index_ReturnsViewResult_WithAListOfCategories()
        {
            var mockRepo = new Mock<ITaskRepository>();
            mockRepo.Setup(repo => repo.GetAllTasks()).ReturnsAsync(GetTestTasks());
            var controller = new TasksController(mockRepo.Object);
            var result = controller.GetAllTasks().Result;
            var viewResult = Assert.IsType<Task<IActionResult>>(result);
            var model = Assert.IsAssignableFrom<List<PersonalChannelWebAPI.Models.Task>>(
                viewResult
                );
        }
    }
}
