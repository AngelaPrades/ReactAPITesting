﻿using System;
using PersonalChannelWebAPI.Models;
using System.Collections.Generic;
using System.Text;

namespace TestWebAPI
{
    public class DummyDataDBInitializer
    {

        public void Seed(WebAPIPersonalChannelContext context)
        {
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            context.Tasks.AddRange(
                new Task() { Name = "Task 1", IsComplete = false },
                new Task() { Name = "Task 2", IsComplete = false },
                new Task() { Name = "Task 3", IsComplete = false },
                new Task() { Name = "Task 4", IsComplete = false }
            );

            context.SaveChanges();
        }
    }
}
