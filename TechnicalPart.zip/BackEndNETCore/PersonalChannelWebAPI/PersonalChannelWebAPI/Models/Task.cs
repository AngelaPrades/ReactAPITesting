﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PersonalChannelWebAPI.Models
{
    public partial class Task
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsComplete { get; set; }
    }
}
