﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PersonalChannelWebAPI.Models;
using PersonalChannelWebAPI.Repositories;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PersonalChannelWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TasksController : Controller
    {
        ITaskRepository taskRepository;
        private WebAPIPersonalChannelContext db = new WebAPIPersonalChannelContext();

        public TasksController(ITaskRepository _taskRepository)
        {
            taskRepository = _taskRepository;
        }

        // GET: api/<controller>
        [HttpGet]
        [Route("GetAllTasks")]
        public async Task<IActionResult> GetAllTasks()
        {
            try
            {
                var tasks = await taskRepository.GetAllTasks();
                if (tasks == null)
                {
                    return NotFound();
                }

                return Ok(tasks);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpGet]
        [Route("GetTaskById/{taskId}")]
        public async Task<IActionResult> GetTaskById(int? taskId)
        {
            try
            {
                var tasks = await taskRepository.GetTaskById(taskId);
                if (tasks == null)
                {
                    return NotFound();
                }

                return Ok(tasks);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpPost]
        [Route("AddTask")]
        public async Task<IActionResult> AddTask([FromBody] Models.Task model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var taskId = await taskRepository.AddTaskAsync(model);
                    if (taskId > 0)
                    {
                        return Ok(taskId);
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                catch (Exception)
                {
                    return BadRequest();
                }
            }
            return BadRequest();
        }

        [HttpDelete]
        [Route("DeleteTask/{taskId}")]
        public async Task<IActionResult> DeleteTask(int? taskId)
        {
            int result = 0;

            if (taskId == null)
            {
                return BadRequest();
            }

            try
            {
                result = await taskRepository.DeleteTask(taskId);
                if (result == 0)
                {
                    return NotFound();
                }
                return Ok();
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }


        [HttpPut]
        [Route("UpdateTask/{taskId}")]
        public async Task<IActionResult> UpdateTask([FromBody] Models.Task model, int? taskId)
        {
            if (ModelState.IsValid)
            {
                int result = 0;
                if (taskId == null)
                {
                    return BadRequest();
                }
                try
                {
                    Models.Task task = await taskRepository.GetTaskById(taskId);
                    task.IsComplete = model.IsComplete;
                    await taskRepository.UpdateTask(task);

                    return Ok();
                }
                catch (Exception ex)
                {
                    if (ex.GetType().FullName == "Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException")
                    {
                        return NotFound();
                    }

                    return BadRequest();
                }
            }

            return BadRequest();
        }
    }
}
