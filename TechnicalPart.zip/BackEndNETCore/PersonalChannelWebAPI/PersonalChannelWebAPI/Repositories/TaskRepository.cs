﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PersonalChannelWebAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace PersonalChannelWebAPI.Repositories
{
    public class TaskRepository : ITaskRepository
    {
        private WebAPIPersonalChannelContext db;

        public TaskRepository(WebAPIPersonalChannelContext _db)
        {
            this.db = _db;
        }
        public async Task<int> AddTaskAsync(Models.Task task)
        {
            if (db != null)
            {
                var isCompleted = task.IsComplete;
                task.IsComplete = true;
                await db.Tasks.AddAsync(task);
                await db.SaveChangesAsync();
                if (isCompleted == false)
                {
                    task.IsComplete = false;
                    db.Tasks.Attach(task);
                    await db.SaveChangesAsync();
                }
                return task.Id;
            }
            return 0;
        }

        public async Task<int> DeleteTask(int? taskId)
        {
            int result = 0;

            if (db != null)
            {
                var task = await db.Tasks.FirstOrDefaultAsync(x => x.Id == taskId);
                if (task != null)
                {
                    db.Tasks.Remove(task);
                    result = await db.SaveChangesAsync();
                }
            }
            return result;
        }

        public async Task<List<Models.Task>> GetAllTasks()
        {
            if (db != null)
            {
                return await db.Tasks.ToListAsync();
            }
            return null;
        }

        public async Task<Models.Task> GetTaskById(int? taskId)
        {
            if (db != null)
            {
                return await db.Tasks.FirstOrDefaultAsync(x => x.Id == taskId);
            }
            return null;
        }

        public async System.Threading.Tasks.Task UpdateTask(Models.Task task)
        {
            if (db != null)
            {
                db.Tasks.Update(task);
                await db.SaveChangesAsync();
            }
        }
    }
}
