﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PersonalChannelWebAPI.Repositories
{
    public interface ITaskRepository
    {
        Task<List<Models.Task>> GetAllTasks();

        Task<Models.Task> GetTaskById(int? taskId);

        Task<int> AddTaskAsync(Models.Task task);

        Task<int> DeleteTask(int? taskId);

        Task UpdateTask(Models.Task task);
    }
}
