import axios from "axios";

const API_URL="https://localhost:44352/api/Tasks/"

const https = require('https');
const agent = new https.Agent({  
  rejectUnauthorized: false
});

async function createTodo(task) {
  const { data: newTodo } = await axios.post(API_URL + 'AddTask',
    {
      name: task,
      isComplete: false
    }, { httpsAgent: agent }
  );
  return newTodo;
}

async function deleteTodo(id) {
  const message = await axios.delete(`${API_URL}DeleteTask/${id}`);
  return message;
}

async function updateTodo(id, payload) {
  await axios.put(`${API_URL}UpdateTask/${id}`, payload);
  return payload;
}

async function getAllTodos() {
  const { data: todos } = await axios.get(API_URL + 'GetAllTasks', { httpsAgent: agent });
  return todos;
}

export default { createTodo, deleteTodo, updateTodo, getAllTodos };
