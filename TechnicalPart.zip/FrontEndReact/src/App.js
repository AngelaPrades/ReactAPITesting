import React, { useState, useEffect } from "react";
import "./App.css";
import APIHelper from "./APIHelper.js";

function App() {
  const [todos, setTodos] = useState([]);
  const [todo, setTodo] = useState("");
  const groups = [
    {name: "Completed Tasks", isComplete: true},
    {name: "Not Completed Tasks", isComplete: false},
  ]

  useEffect(() => {
    const fetchTodoAndSetTodos = async () => {
      const todos = await APIHelper.getAllTodos();
      setTodos(todos);
    };
    fetchTodoAndSetTodos();
  }, []);

  const createTodo = async e => {
    e.preventDefault();
    if (!todo) {
      alert("please enter a task");
      return;
    }
    if (todos.some(( task ) => task.name === todo)) {
      alert(`Task: ${todo} already exists`);
      return;
    }
    const idNewTodo = await APIHelper.createTodo(todo);
    const newTodo = { id: idNewTodo, name: todo, isComplete: false };
    console.log(newTodo);
    setTodos([...todos, newTodo]);
  };

  const deleteTodo = async (e, id) => {
    try {
      e.stopPropagation();
      await APIHelper.deleteTodo(id);
      setTodos(todos.filter(({ id: i }) => id !== i));
    } catch (err) {}
  };

  const updateTodo = async (e, id) => {
    e.stopPropagation();
    const payload = todos.find((task) => task.id === id);
    payload.isComplete = !payload.isComplete;
    const updatedTodo  = await APIHelper.updateTodo(id, payload);
    setTodos(todos.map((todo)=> todo.id === id ? updatedTodo: todo));
  };

  return (
    <div className="App">
      <div>
        <input
          type="text"
          value={todo}
          onChange={({ target }) => setTodo(target.value)}
          placeholder="Enter a task"
        />
        <button type="button" onClick={createTodo}>
          Add
        </button>
      </div>

      <div>
        {groups.map(group => {
          return (
            <div>
              <h2>{group.name}</h2>
              <ul>
                {
                todos?.filter(todo => group.isComplete===todo.isComplete)
                .map((todo, i) => {
                  return(
                  <div>
                      <li key={i} onClick={e => updateTodo(e, todo.id)} 
                      className={todo.isComplete ? "completed" : ""}>
                        {todo.name}
                        <button type="button" onClick={e => deleteTodo(e, todo.id)}>
                          Delete
                        </button>
                      </li>
                  </div>)
              })}
              </ul>
            </div>)})}
      </div>
    </div>
  );
}

export default App;
