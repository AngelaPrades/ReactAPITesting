import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';
import APIHelper from './APIHelper';
//jest.mock('axios'); // This overwrites axios methods with jest Mock
import axios from 'axios';

describe('App Component', function() {

  const url = 'https://localhost:44352/api/Tasks/';
  const onComplete = jest.fn();
  const data = {};

  it('renders with correct text', function() {
    var app = render(<App />);
    expect(screen.getByText('Completed Tasks')).toBeInTheDocument();
    expect(screen.getByText('Not Completed Tasks')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Enter a task')).toBeInTheDocument();
  });

  it('calls "onClick" prop on button click', () => {
    const onClick = jest.fn();
    const { getByText } = render(<Button onClick={onClick} />);
  
    fireEvent.click(getByText(/click me nao/i));
    expect(onClick).toHaveBeenCalled();
  });

  it('should call onComplete callback with response', async () => {
    const API_URL="https://localhost:44352/api/Tasks/"
    //const data = await axios.get(API_URL + 'GetAllTasks'); 
    const data = await APIHelper.getAllTodos(onComplete)
    expect(data).NotNull()
  });

  const renderComponent = ({ count }) =>
  render(
    <FetchMock
      mocks={[
        { matcher: '/count', method: 'GET', response: { count } },
        { matcher: '/count', method: 'POST', response: { count: count + 1 } }
      ]}
    >
      <ServerCounter />
    </FetchMock>
  );


});